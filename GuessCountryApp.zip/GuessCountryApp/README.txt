Угадай страну — Android-проект (WebView)

КАК СОБРАТЬ APK
1. Установи Android Studio (https://developer.android.com/studio).
2. File -> Open -> выбери папку GuessCountryApp. Дождись Gradle Sync
   (нужен интернет: Studio сама скачает Gradle и зависимости).
3. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
   Готовый файл: app/build/outputs/apk/debug/app-debug.apk
4. Скинь app-debug.apk на телефон и открой (разреши установку из неизвестных источников).

Игра лежит в app/src/main/assets/index.html и работает без интернета.
Чтобы обновить игру, замени этот файл и пересобери APK.

СБОРКА В ОБЛАКЕ (без Android Studio)
1. Создай репозиторий на github.com и загрузи в него содержимое папки GuessCountryApp
   (папка .github должна оказаться в корне репозитория).
2. Вкладка Actions -> Build APK -> Run workflow.
3. Через 3-5 минут скачай app-debug.apk из раздела Artifacts (GuessCountry-apk).
